package com.example.metagoplus.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.metagoplus.MainActivity;
import com.example.metagoplus.R;

public class OnboardingActivity extends AppCompatActivity {
    private int currentStep = 0;
    private final int totalSteps = 3;
    private ImageView imageView;
    private TextView textView;
    private Button nextButton;
    private Button skipButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);
        imageView = findViewById(R.id.onboarding_image);
        textView = findViewById(R.id.onboarding_text);
        nextButton = findViewById(R.id.onboarding_next);
        skipButton = findViewById(R.id.onboarding_skip);
        updateStep();
        nextButton.setOnClickListener(v -> {
            currentStep++;
            if (currentStep < totalSteps) {
                updateStep();
            } else {
                startActivity(new Intent(this, MainActivity.class));
                finish();
            }
        });
        skipButton.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    private void animateStepChange() {
        AlphaAnimation fadeOut = new AlphaAnimation(1.0f, 0.0f);
        fadeOut.setDuration(200);
        fadeOut.setFillAfter(true);
        AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(200);
        fadeIn.setFillAfter(true);
        imageView.startAnimation(fadeOut);
        textView.startAnimation(fadeOut);
        fadeOut.setAnimationListener(new android.view.animation.Animation.AnimationListener() {
            @Override
            public void onAnimationStart(android.view.animation.Animation animation) {}
            @Override
            public void onAnimationEnd(android.view.animation.Animation animation) {
                updateStepContent();
                imageView.startAnimation(fadeIn);
                textView.startAnimation(fadeIn);
            }
            @Override
            public void onAnimationRepeat(android.view.animation.Animation animation) {}
        });
    }

    private void updateStep() {
        animateStepChange();
    }

    private void updateStepContent() {
        switch (currentStep) {
            case 0:
                imageView.setImageResource(R.drawable.onboarding_1);
                textView.setText("Organiza tus retos personales en un solo lugar. ¡Agrega, edita y elimina retos fácilmente!");
                nextButton.setText("Siguiente");
                break;
            case 1:
                imageView.setImageResource(R.drawable.onboarding_2);
                textView.setText("Marca tus retos como completados y recibe frases motivacionales e inspiración diaria.");
                nextButton.setText("Siguiente");
                break;
            case 2:
                imageView.setImageResource(R.drawable.onboarding_3);
                textView.setText("Consulta a la IA, revisa estadísticas y personaliza tu experiencia con modo claro/oscuro.");
                nextButton.setText("¡Empezar!");
                break;
        }
    }
}
