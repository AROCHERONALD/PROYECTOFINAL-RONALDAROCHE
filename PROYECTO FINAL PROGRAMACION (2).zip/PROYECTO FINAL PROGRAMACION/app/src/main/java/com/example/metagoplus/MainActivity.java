package com.example.metagoplus;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.metagoplus.model.Reto;
import com.example.metagoplus.ui.AddRetoActivity;
import com.example.metagoplus.ui.StatisticsActivity; // Changed EstadisticaActivity to StatisticsActivity
import com.example.metagoplus.ui.MotivationalPhraseActivity;
import com.example.metagoplus.ui.RetoListAdapter;
import com.example.metagoplus.viewmodel.RetoViewModel;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity implements RetoListAdapter.OnRetoCompletedListener {

    private RetoViewModel mRetoViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = getSharedPreferences("onboarding", MODE_PRIVATE);
        if (!prefs.getBoolean("completed", false)) {
            startActivity(new Intent(this, com.example.metagoplus.ui.OnboardingActivity.class));
            finish();
            return;
        }
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mRetoViewModel = new ViewModelProvider(this).get(RetoViewModel.class);

        RecyclerView proximosRecyclerView = findViewById(R.id.recyclerview_proximos);
        final RetoListAdapter proximosAdapter = new RetoListAdapter(new RetoListAdapter.RetoDiff(), this);
        proximosRecyclerView.setAdapter(proximosAdapter);
        proximosRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        RecyclerView pendientesRecyclerView = findViewById(R.id.recyclerview_pendientes);
        final RetoListAdapter pendientesAdapter = new RetoListAdapter(new RetoListAdapter.RetoDiff(), this);
        pendientesRecyclerView.setAdapter(pendientesAdapter);
        pendientesRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        RecyclerView completadosRecyclerView = findViewById(R.id.recyclerview_completados);
        final RetoListAdapter completadosAdapter = new RetoListAdapter(new RetoListAdapter.RetoDiff(), this);
        completadosRecyclerView.setAdapter(completadosAdapter);
        completadosRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mRetoViewModel.getUpcomingRetos().observe(this, proximosAdapter::submitList);
        mRetoViewModel.getPendingRetos().observe(this, pendientesAdapter::submitList);
        mRetoViewModel.getCompletedRetos().observe(this, completadosAdapter::submitList);

        Button addRetoButton = findViewById(R.id.button_add_reto);
        addRetoButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddRetoActivity.class);
            startActivity(intent);
        });

        Button estadisticasButton = findViewById(R.id.button_estadisticas);
        estadisticasButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, StatisticsActivity.class); // Changed EstadisticaActivity to StatisticsActivity
            startActivity(intent);
        });

        Button toggleThemeButton = findViewById(R.id.button_toggle_theme);
        toggleThemeButton.setOnClickListener(v -> {
            int currentNightMode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            if (currentNightMode == Configuration.UI_MODE_NIGHT_YES) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            }
        });

        Button showTutorialButton = findViewById(R.id.button_show_tutorial);
        showTutorialButton.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, com.example.metagoplus.ui.OnboardingActivity.class));
        });

        // Configurar listeners de editar/eliminar para cada adapter
        RetoListAdapter.OnRetoEditDeleteListener editDeleteListener = new RetoListAdapter.OnRetoEditDeleteListener() {
            @Override
            public void onEditReto(Reto reto) {
                Intent intent = new Intent(MainActivity.this, AddRetoActivity.class);
                intent.putExtra("RETO_EDIT", reto);
                startActivity(intent);
            }
            @Override
            public void onDeleteReto(Reto reto) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Eliminar reto")
                        .setMessage("¿Estás seguro de que deseas eliminar este reto?")
                        .setPositiveButton("Eliminar", (dialog, which) -> {
                            mRetoViewModel.delete(reto);
                            Toast.makeText(MainActivity.this, "Reto eliminado", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Cancelar", null)
                        .show();
            }
        };
        proximosAdapter.setOnRetoEditDeleteListener(editDeleteListener);
        pendientesAdapter.setOnRetoEditDeleteListener(editDeleteListener);
        completadosAdapter.setOnRetoEditDeleteListener(editDeleteListener);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_toggle_theme) {
            int currentNightMode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            if (currentNightMode == Configuration.UI_MODE_NIGHT_YES) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRetoCompleted(Reto reto, boolean isCompleted) {
        reto.setCompletado(isCompleted);
        mRetoViewModel.update(reto);
        if (isCompleted) {
            Intent intent = new Intent(MainActivity.this, MotivationalPhraseActivity.class);
            startActivity(intent);
        }
    }
}