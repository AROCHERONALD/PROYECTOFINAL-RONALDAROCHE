package com.example.metagoplus.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.metagoplus.data.RetoRepository;
import com.example.metagoplus.model.Reto;

import java.util.List;

public class RetoViewModel extends AndroidViewModel {

    private RetoRepository mRepository;

    private final LiveData<List<Reto>> mAllRetos;
    private final LiveData<List<Reto>> mUpcomingRetos;
    private final LiveData<List<Reto>> mPendingRetos;
    private final LiveData<List<Reto>> mCompletedRetos;

    public RetoViewModel (Application application) {
        super(application);
        mRepository = new RetoRepository(application);
        mAllRetos = mRepository.getAllRetos();
        mUpcomingRetos = mRepository.getUpcomingRetos();
        mPendingRetos = mRepository.getPendingRetos();
        mCompletedRetos = mRepository.getCompletedRetos();
    }

    public LiveData<List<Reto>> getAllRetos() { return mAllRetos; }

    public LiveData<List<Reto>> getUpcomingRetos() { return mUpcomingRetos; }

    public LiveData<List<Reto>> getPendingRetos() { return mPendingRetos; }

    public LiveData<List<Reto>> getCompletedRetos() { return mCompletedRetos; }

    public void insert(Reto reto) { mRepository.insert(reto); }

    public void update(Reto reto) { mRepository.update(reto); }

    public void delete(Reto reto) { mRepository.delete(reto); } // Added delete method

    public interface InsertCallback {
        void onInsert(Reto retoConId);
    }

    public void insertWithCallback(Reto reto, InsertCallback callback) {
        mRepository.insertWithCallback(reto, callback);
    }
}
