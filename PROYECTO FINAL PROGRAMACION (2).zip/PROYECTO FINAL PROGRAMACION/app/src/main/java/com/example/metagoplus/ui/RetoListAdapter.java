package com.example.metagoplus.ui;

import android.graphics.drawable.Animatable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.metagoplus.R;
import com.example.metagoplus.model.Reto;

public class RetoListAdapter extends ListAdapter<Reto, RetoListAdapter.RetoViewHolder> {

    private OnRetoCompletedListener listener;
    private OnRetoEditDeleteListener editDeleteListener;

    public RetoListAdapter(@NonNull DiffUtil.ItemCallback<Reto> diffCallback, OnRetoCompletedListener listener) {
        super(diffCallback);
        this.listener = listener;
    }

    public void setOnRetoEditDeleteListener(OnRetoEditDeleteListener listener) {
        this.editDeleteListener = listener;
    }

    @NonNull
    @Override
    public RetoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.reto_list_item, parent, false);
        return new RetoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RetoViewHolder holder, int position) {
        Reto current = getItem(position);
        holder.bind(current, listener, editDeleteListener);
    }

    static class RetoViewHolder extends RecyclerView.ViewHolder {
        private final TextView retoNombre;
        private final TextView retoDescripcion;
        private final TextView retoFecha;
        private final CheckBox completadoCheckbox;
        private final ImageButton editButton;
        private final ImageButton deleteButton;
        private final ImageView checkAnimView;

        private RetoViewHolder(View itemView) {
            super(itemView);
            retoNombre = itemView.findViewById(R.id.textview_reto_nombre);
            retoDescripcion = itemView.findViewById(R.id.textview_reto_descripcion);
            retoFecha = itemView.findViewById(R.id.textview_reto_fecha);
            completadoCheckbox = itemView.findViewById(R.id.checkbox_completado);
            editButton = itemView.findViewById(R.id.button_edit_reto);
            deleteButton = itemView.findViewById(R.id.button_delete_reto);
            checkAnimView = itemView.findViewById(R.id.imageview_check_anim);
        }

        public void bind(Reto reto, OnRetoCompletedListener listener, OnRetoEditDeleteListener editDeleteListener) {
            retoNombre.setText(reto.getNombre());
            retoDescripcion.setText(reto.getDescripcion());
            retoFecha.setText("Fecha Límite: " + reto.getFechaLimite());
            completadoCheckbox.setChecked(reto.isCompletado());

            // Mostrar animación solo si el reto está completado
            if (reto.isCompletado()) {
                checkAnimView.setVisibility(View.VISIBLE);
                if (checkAnimView.getDrawable() instanceof Animatable) {
                    ((Animatable) checkAnimView.getDrawable()).start();
                }
            } else {
                checkAnimView.setVisibility(View.GONE);
            }

            completadoCheckbox.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onRetoCompleted(reto, completadoCheckbox.isChecked());
                }
            });
            if (editDeleteListener != null) {
                editButton.setOnClickListener(v -> editDeleteListener.onEditReto(reto));
                deleteButton.setOnClickListener(v -> editDeleteListener.onDeleteReto(reto));
            }
        }
    }

    public static class RetoDiff extends DiffUtil.ItemCallback<Reto> {
        @Override
        public boolean areItemsTheSame(@NonNull Reto oldItem, @NonNull Reto newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Reto oldItem, @NonNull Reto newItem) {
            return oldItem.getNombre().equals(newItem.getNombre()) &&
                    oldItem.getDescripcion().equals(newItem.getDescripcion()) &&
                    oldItem.getFechaLimite().equals(newItem.getFechaLimite()) &&
                    oldItem.isCompletado() == newItem.isCompletado();
        }
    }

    public interface OnRetoCompletedListener {
        void onRetoCompleted(Reto reto, boolean isCompleted);
    }

    public interface OnRetoEditDeleteListener {
        void onEditReto(Reto reto);
        void onDeleteReto(Reto reto);
    }
}
