package com.example.metagoplus.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete; // Added import for @Delete
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.metagoplus.model.Reto;

import java.util.List;

@Dao
public interface RetoDao {
    @Insert
    void insert(Reto reto);

    @Insert
    long insertWithReturnId(Reto reto);

    @Update
    void update(Reto reto);

    @Delete // Added @Delete annotation for the delete method
    void delete(Reto reto); // Added delete(Reto reto) method

    @Query("DELETE FROM retos")
    void deleteAll();

    @Query("SELECT * FROM retos ORDER BY fechaLimite ASC")
    LiveData<List<Reto>> getAllRetos();

    @Query("SELECT * FROM retos WHERE completado = 0 AND date(fechaLimite) >= date('now') ORDER BY fechaLimite ASC")
    LiveData<List<Reto>> getUpcomingRetos();

    @Query("SELECT * FROM retos WHERE completado = 0 AND date(fechaLimite) < date('now') ORDER BY fechaLimite ASC")
    LiveData<List<Reto>> getPendingRetos();

    @Query("SELECT * FROM retos WHERE completado = 1 ORDER BY fechaLimite DESC")
    LiveData<List<Reto>> getCompletedRetos();
}
