package com.example.metagoplus.data;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.metagoplus.model.Reto;

import java.util.List;

public class RetoRepository {

    private RetoDao mRetoDao;
    private LiveData<List<Reto>> mAllRetos;
    private LiveData<List<Reto>> mUpcomingRetos;
    private LiveData<List<Reto>> mPendingRetos;
    private LiveData<List<Reto>> mCompletedRetos;

    public RetoRepository(Application application) {
        RetoDatabase db = RetoDatabase.getDatabase(application);
        mRetoDao = db.retoDao();
        mAllRetos = mRetoDao.getAllRetos();
        mUpcomingRetos = mRetoDao.getUpcomingRetos();
        mPendingRetos = mRetoDao.getPendingRetos();
        mCompletedRetos = mRetoDao.getCompletedRetos();
    }

    public LiveData<List<Reto>> getAllRetos() {
        return mAllRetos;
    }

    public LiveData<List<Reto>> getUpcomingRetos() {
        return mUpcomingRetos;
    }

    public LiveData<List<Reto>> getPendingRetos() {
        return mPendingRetos;
    }

    public LiveData<List<Reto>> getCompletedRetos() {
        return mCompletedRetos;
    }

    public void insert(Reto reto) {
        RetoDatabase.databaseWriteExecutor.execute(() -> {
            mRetoDao.insert(reto);
        });
    }

    public void update(Reto reto) {
        RetoDatabase.databaseWriteExecutor.execute(() -> {
            mRetoDao.update(reto);
        });
    }

    public void delete(Reto reto) { // Added delete method
        RetoDatabase.databaseWriteExecutor.execute(() -> {
            mRetoDao.delete(reto);
        });
    }

    public void insertWithCallback(Reto reto, final com.example.metagoplus.viewmodel.RetoViewModel.InsertCallback callback) {
        RetoDatabase.databaseWriteExecutor.execute(() -> {
            long id = mRetoDao.insertWithReturnId(reto);
            reto.setId((int) id);
            if (callback != null) {
                callback.onInsert(reto);
            }
        });
    }
}
