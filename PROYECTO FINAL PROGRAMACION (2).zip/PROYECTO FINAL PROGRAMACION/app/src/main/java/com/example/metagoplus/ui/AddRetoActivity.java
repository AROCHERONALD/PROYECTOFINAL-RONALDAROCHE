package com.example.metagoplus.ui;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.metagoplus.R;
import com.example.metagoplus.model.Reto;
import com.example.metagoplus.utils.RetoReminderReceiver;
import com.example.metagoplus.viewmodel.RetoViewModel;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddRetoActivity extends AppCompatActivity {

    private EditText mEditNombreView;
    private EditText mEditDescripcionView;
    private TextView mTextViewFechaLimite;
    private RetoViewModel mRetoViewModel;
    private Calendar mCalendar;
    private Reto retoEdit = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_reto);

        mRetoViewModel = new ViewModelProvider(this).get(RetoViewModel.class);

        mEditNombreView = findViewById(R.id.edittext_reto_nombre);
        mEditDescripcionView = findViewById(R.id.edittext_reto_descripcion);
        mTextViewFechaLimite = findViewById(R.id.textview_fecha_limite);
        mCalendar = Calendar.getInstance();

        // Revisar si se está editando un reto
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("RETO_EDIT")) {
            retoEdit = (Reto) intent.getSerializableExtra("RETO_EDIT");
            if (retoEdit != null) {
                mEditNombreView.setText(retoEdit.getNombre());
                mEditDescripcionView.setText(retoEdit.getDescripcion());
                mTextViewFechaLimite.setText(retoEdit.getFechaLimite());
                // Ajustar el calendario interno a la fecha del reto
                try {
                    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
                    java.util.Date date = sdf.parse(retoEdit.getFechaLimite());
                    if (date != null) mCalendar.setTime(date);
                } catch (Exception ignored) {}
            }
        }

        final Button button = findViewById(R.id.button_save);
        button.setOnClickListener(view -> {
            if (validateInput()) {
                if (retoEdit != null) {
                    retoEdit.setNombre(mEditNombreView.getText().toString());
                    retoEdit.setDescripcion(mEditDescripcionView.getText().toString());
                    retoEdit.setFechaLimite(mTextViewFechaLimite.getText().toString());
                    mRetoViewModel.update(retoEdit);
                    scheduleRetoReminder(retoEdit);
                    Toast.makeText(this, "Reto actualizado", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Reto reto = new Reto(
                            mEditNombreView.getText().toString(),
                            mEditDescripcionView.getText().toString(),
                            mTextViewFechaLimite.getText().toString(),
                            false
                    );
                    mRetoViewModel.insertWithCallback(reto, retoConId -> {
                        runOnUiThread(() -> {
                            scheduleRetoReminder(retoConId);
                            Toast.makeText(this, "Reto agregado", Toast.LENGTH_SHORT).show();
                            finish();
                        });
                    });
                }
            }
        });

        mTextViewFechaLimite.setOnClickListener(v -> showDatePickerDialog());
    }

    private void showDatePickerDialog() {
        DatePickerDialog.OnDateSetListener dateSetListener = (view, year, month, dayOfMonth) -> {
            mCalendar.set(Calendar.YEAR, year);
            mCalendar.set(Calendar.MONTH, month);
            mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabel();
        };

        new DatePickerDialog(AddRetoActivity.this, dateSetListener,
                mCalendar.get(Calendar.YEAR),
                mCalendar.get(Calendar.MONTH),
                mCalendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void updateLabel() {
        String myFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        mTextViewFechaLimite.setText(sdf.format(mCalendar.getTime()));
    }

    private boolean validateInput() {
        if (TextUtils.isEmpty(mEditNombreView.getText())) {
            mEditNombreView.setError("El nombre no puede estar vacío.");
            return false;
        }
        if (TextUtils.isEmpty(mEditDescripcionView.getText())) {
            mEditDescripcionView.setError("La descripción no puede estar vacía.");
            return false;
        }
        if (TextUtils.isEmpty(mTextViewFechaLimite.getText()) || mTextViewFechaLimite.getText().toString().equals("Seleccionar fecha límite")) {
            Toast.makeText(this, "Por favor, selecciona una fecha límite.", Toast.LENGTH_SHORT).show();
            return false;
        }
        // Validar que la fecha no sea en el pasado
        if (mCalendar.getTimeInMillis() < System.currentTimeMillis() - 86400000) { // 1 día en milisegundos para margen
             Toast.makeText(this, "La fecha límite no puede ser en el pasado.", Toast.LENGTH_SHORT).show();
             return false;
        }
        return true;
    }

    private void scheduleRetoReminder(Reto reto) {
        // Notificar 1 día antes de la fecha límite, a las 9:00 AM
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            java.util.Date fecha = sdf.parse(reto.getFechaLimite());
            if (fecha == null) return;
            Calendar cal = Calendar.getInstance();
            cal.setTime(fecha);
            cal.add(Calendar.DAY_OF_YEAR, -1); // 1 día antes
            cal.set(Calendar.HOUR_OF_DAY, 9);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            if (cal.getTimeInMillis() < System.currentTimeMillis()) return; // No programar si ya pasó
            Intent intent = new Intent(this, RetoReminderReceiver.class);
            intent.putExtra(RetoReminderReceiver.EXTRA_RETO_NOMBRE, reto.getNombre());
            intent.putExtra(RetoReminderReceiver.EXTRA_RETO_ID, reto.getId());
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, reto.getId(), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
        } catch (Exception ignored) {}
    }
}
