package com.example.metagoplus.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.metagoplus.model.Reto;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Reto.class}, version = 1, exportSchema = false)
public abstract class RetoDatabase extends RoomDatabase {

    public abstract RetoDao retoDao();

    private static volatile RetoDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static RetoDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (RetoDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    RetoDatabase.class, "reto_database")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
