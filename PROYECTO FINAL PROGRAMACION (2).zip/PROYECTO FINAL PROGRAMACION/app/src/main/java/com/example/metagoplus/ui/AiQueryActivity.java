package com.example.metagoplus.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.metagoplus.BuildConfig;
import com.example.metagoplus.R;
import com.example.metagoplus.api.ApiClient;
import com.example.metagoplus.api.ChatRequest;
import com.example.metagoplus.api.ChatResponse;
import com.example.metagoplus.api.Message;
import com.example.metagoplus.api.OpenAIApi;

import java.util.Collections;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AiQueryActivity extends AppCompatActivity {

    private EditText mQueryEditText;
    private Button mSendQueryButton;
    private TextView mResponseTextView;
    private ProgressBar mProgressBar;
    private OpenAIApi mOpenAIApi;
    private final String API_KEY = "Bearer " + BuildConfig.OPENAI_API_KEY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai_query);

        mQueryEditText = findViewById(R.id.edittext_query);
        mSendQueryButton = findViewById(R.id.button_send_query);
        mResponseTextView = findViewById(R.id.textview_ai_response);
        mProgressBar = findViewById(R.id.progressbar_query_loading);

        mOpenAIApi = ApiClient.getClient().create(OpenAIApi.class);

        mSendQueryButton.setOnClickListener(v -> {
            String query = mQueryEditText.getText().toString();
            if (!TextUtils.isEmpty(query)) {
                sendQueryToAi(query);
            } else {
                Toast.makeText(AiQueryActivity.this, "Por favor, escribe una consulta.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendQueryToAi(String query) {
        mProgressBar.setVisibility(View.VISIBLE);
        mResponseTextView.setText("");

        ChatRequest request = new ChatRequest(
                "gpt-3.5-turbo",
                Collections.singletonList(new Message("user", query))
        );

        mOpenAIApi.getChatCompletion(API_KEY, request).enqueue(new Callback<ChatResponse>() {
            @Override
            public void onResponse(Call<ChatResponse> call, Response<ChatResponse> response) {
                mProgressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null && !response.body().getChoices().isEmpty()) {
                    String result = response.body().getChoices().get(0).getMessage().getContent();
                    mResponseTextView.setText(result);
                } else {
                    mResponseTextView.setText("Error al obtener la respuesta.");
                    Toast.makeText(AiQueryActivity.this, "Error: " + response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ChatResponse> call, Throwable t) {
                mProgressBar.setVisibility(View.GONE);
                mResponseTextView.setText("Fallo de red. No se pudo conectar con el servidor.");
                Toast.makeText(AiQueryActivity.this, "Fallo: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
