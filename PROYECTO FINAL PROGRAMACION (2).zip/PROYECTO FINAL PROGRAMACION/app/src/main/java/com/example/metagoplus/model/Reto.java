package com.example.metagoplus.model;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "retos")
public class Reto implements Parcelable {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String nombre;
    private String descripcion;
    private String fechaLimite;
    private boolean completado;

    // Existing constructor
    public Reto(String nombre, String descripcion, String fechaLimite, boolean completado) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fechaLimite = fechaLimite;
        this.completado = completado;
    }

    // Parcelable constructor
    protected Reto(Parcel in) {
        id = in.readInt();
        nombre = in.readString();
        descripcion = in.readString();
        fechaLimite = in.readString();
        completado = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(nombre);
        dest.writeString(descripcion);
        dest.writeString(fechaLimite);
        dest.writeByte((byte) (completado ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Reto> CREATOR = new Creator<Reto>() {
        @Override
        public Reto createFromParcel(Parcel in) {
            return new Reto(in);
        }

        @Override
        public Reto[] newArray(int size) {
            return new Reto[size];
        }
    };

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFechaLimite() {
        return fechaLimite;
    }

    public void setFechaLimite(String fechaLimite) {
        this.fechaLimite = fechaLimite;
    }

    public boolean isCompletado() {
        return completado;
    }

    public void setCompletado(boolean completado) {
        this.completado = completado;
    }

    public String getEstado() {
        return completado ? "completado" : "pendiente";
    }
}
