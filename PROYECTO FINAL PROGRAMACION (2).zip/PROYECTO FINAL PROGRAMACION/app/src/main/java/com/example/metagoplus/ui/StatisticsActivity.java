package com.example.metagoplus.ui;

import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.metagoplus.viewmodel.RetoViewModel;
import com.example.metagoplus.model.Reto;
import com.example.metagoplus.R;
import java.util.List;

public class StatisticsActivity extends AppCompatActivity {
    private RetoViewModel retoViewModel;
    private TextView totalRetosText, completadosText, pendientesText, progresoText;
    private ProgressBar progresoBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        totalRetosText = findViewById(R.id.text_total_retos);
        completadosText = findViewById(R.id.text_completados);
        pendientesText = findViewById(R.id.text_pendientes);
        progresoText = findViewById(R.id.text_progreso);
        progresoBar = findViewById(R.id.progressBar);

        retoViewModel = new ViewModelProvider(this).get(RetoViewModel.class);
        retoViewModel.getAllRetos().observe(this, this::updateStats);
        retoViewModel.getCompletedRetos().observe(this, completed -> updateStats(retoViewModel.getAllRetos().getValue()));
        retoViewModel.getPendingRetos().observe(this, pending -> updateStats(retoViewModel.getAllRetos().getValue()));
    }

    private void updateStats(List<Reto> allRetos) {
        if (allRetos == null) return;
        int total = allRetos.size();
        int completados = 0;
        int pendientes = 0;
        for (Reto r : allRetos) {
            if (r.getEstado().equalsIgnoreCase("completado")) completados++;
            else pendientes++;
        }
        int progreso = total == 0 ? 0 : (int) ((completados * 100.0f) / total);
        totalRetosText.setText("Total de retos: " + total);
        completadosText.setText("Completados: " + completados);
        pendientesText.setText("Pendientes: " + pendientes);
        progresoText.setText("Progreso: " + progreso + "%");
        progresoBar.setProgress(progreso);
    }
}
