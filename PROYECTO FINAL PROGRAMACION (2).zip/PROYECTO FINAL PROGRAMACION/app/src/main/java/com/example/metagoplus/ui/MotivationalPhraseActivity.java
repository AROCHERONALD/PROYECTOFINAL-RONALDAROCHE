package com.example.metagoplus.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.metagoplus.R;
import com.example.metagoplus.api.ApiClient;
import com.example.metagoplus.api.ChatRequest;
import com.example.metagoplus.api.ChatResponse;
import com.example.metagoplus.api.Message;
import com.example.metagoplus.api.OpenAIApi;
import com.example.metagoplus.BuildConfig;

import java.util.Collections;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MotivationalPhraseActivity extends AppCompatActivity {

    private TextView mPhraseTextView;
    private ProgressBar mProgressBar;
    private Button mAskIaButton;
    private OpenAIApi mOpenAIApi;
    private String API_KEY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motivational_phrase);
        API_KEY = "Bearer " + BuildConfig.OPENAI_API_KEY;

        mPhraseTextView = findViewById(R.id.textview_motivational_phrase);
        mProgressBar = findViewById(R.id.progressbar_loading);
        mAskIaButton = findViewById(R.id.button_ask_ia);

        mOpenAIApi = ApiClient.getClient().create(OpenAIApi.class);

        getMotivationalPhrase();

        mAskIaButton.setOnClickListener(v -> {
            Intent intent = new Intent(MotivationalPhraseActivity.this, AiQueryActivity.class);
            startActivity(intent);
        });
    }

    private void getMotivationalPhrase() {
        mProgressBar.setVisibility(View.VISIBLE);
        mPhraseTextView.setVisibility(View.GONE);

        ChatRequest request = new ChatRequest(
                "gpt-3.5-turbo",
                Collections.singletonList(new Message("user", "Dame una frase motivacional corta y poderosa para alguien que acaba de completar un reto personal."))
        );

        mOpenAIApi.getChatCompletion(API_KEY, request).enqueue(new Callback<ChatResponse>() {
            @Override
            public void onResponse(Call<ChatResponse> call, Response<ChatResponse> response) {
                mProgressBar.setVisibility(View.GONE);
                mPhraseTextView.setVisibility(View.VISIBLE);

                if (response.isSuccessful() && response.body() != null && !response.body().getChoices().isEmpty()) {
                    String phrase = response.body().getChoices().get(0).getMessage().getContent();
                    mPhraseTextView.setText(phrase);
                } else {
                    mPhraseTextView.setText(getString(R.string.error_obtener_frase));
                    Toast.makeText(MotivationalPhraseActivity.this, getString(R.string.error_obtener_frase_toast), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ChatResponse> call, Throwable t) {
                mProgressBar.setVisibility(View.GONE);
                mPhraseTextView.setVisibility(View.VISIBLE);
                mPhraseTextView.setText(getString(R.string.error_conexion));
                Toast.makeText(MotivationalPhraseActivity.this, getString(R.string.error_red), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
